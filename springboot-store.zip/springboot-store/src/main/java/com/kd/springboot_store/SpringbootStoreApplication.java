package com.kd.springboot_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootStoreApplication.class, args);
	}

}
